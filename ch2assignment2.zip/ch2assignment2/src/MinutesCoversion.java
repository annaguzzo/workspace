// Guzzo 1/30 ch2 assignment 2
import java.util.Scanner;
public class MinutesCoversion {

	public static void main(String[] args) {
		Scanner instuff = new Scanner(System.in);
		
		System.out.print("Enter the number of minutes: ");
		int minutes = instuff.nextInt();
		
		int hours = minutes / 60;
		double days = minutes / (60.0 * 24);
		
		
		System.out.println(minutes + " minutes equals " + hours + " hours and equals "
				+ String.format("%.3f", days) + " days.");
		
		instuff.close();
		
	}

}
