// Guzzo 01/28 in class 1 ch2
public class Initials {

	public static void main(String[] args) {
		String init1="A", init2="E", init3="G";
		System.out.println(init1+"."+init2+"."+init3+".");
		

	}

}
