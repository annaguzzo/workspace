// Guzzo 01/12 in class 2 ch1
public class MovieQuoteInfo {

	public static void main(String[] args) {
		System.out.println("We used to look up at the sky and wonder at our place in the stars.");
		System.out.println("Now, we just look down and worry about our place in the dirt.");
		System.out.println("Joseph Cooper");
		System.out.println("Year 2014");

	}

}
