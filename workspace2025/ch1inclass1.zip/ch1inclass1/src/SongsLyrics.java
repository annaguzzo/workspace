/** Guzzo 01/12 in class 1 ch1
 * 
 */

public class SongsLyrics {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Slow down, you crazy child");
		System.out.println("You're so ambitious for a juvenile");

	}

}
