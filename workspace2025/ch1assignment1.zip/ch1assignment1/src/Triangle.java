// Guzzo 1/15 assignment 1 ch1
public class Triangle {

	public static void main(String[] args) {
		System.out.print("      ");
		System.out.println("T");
		System.out.print("     ");
		System.out.println("TTT");
		System.out.print("    ");
		System.out.println("TTTTT");
		System.out.print("   ");
		System.out.println("TTTTTTT");
		System.out.print("  ");
		System.out.println("TTTTTTTTT");
		System.out.print(" ");
		System.out.println("TTTTTTTTTTT");
		System.out.print("TTTTTTTTTTTTT");
			
		
	}

}
