// Guzzo 1/30 ch2 assignment 1
import java.util.Scanner;

public class Eggs {

	public static void main(String[] args) {
		Scanner instuff = new Scanner(System.in);

		System.out.print("Enter the number of eggs in the order: ");
		int numberOfEggs = instuff.nextInt();
		
		double pricePerDozen = 3.25;
		double pricePerEgg = 0.45; 
		
		int dozens = numberOfEggs / 12;
		int looseEggs = numberOfEggs % 12;
		
		
		double totalCost = (dozens * pricePerDozen) + (looseEggs * pricePerEgg);
		
		System.out.println("You ordered " + numberOfEggs + " eggs. That's " + dozens + " dozen at $"
				+ pricePerDozen + " per dozen and " + looseEggs +" loose eggs at " + pricePerEgg + 
				" cents each for a total of $" + String.format("%.2f", totalCost) + ".");
		
		instuff.close();
	}

}
