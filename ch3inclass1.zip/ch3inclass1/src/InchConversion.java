// Guzzo 2/5 in class chapter 3
import java.util.Scanner;
public class InchConversion {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		double inches;
		System.out.print("Enter a number of inches ");
		inches = input.nextDouble();
		inchesToFeet(inches);
		inchesToYards(inches);
		

	}
	public static void inchesToFeet(double inches) {
		double feet= inches/12;
		System.out.println(inches + " inches equals "+feet + " feet " );
		
	}
	public static void inchesToYards(double inches) {
		double yards= inches/36;
		System.out.println(inches + " inches equals "+yards + " yards ");
	}

}
