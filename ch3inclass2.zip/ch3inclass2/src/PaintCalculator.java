// Guzzo 2/5 in class 2 ch3
import java.util.Scanner;
public class PaintCalculator {

	public static void main(String[] args) {
		double length, width, height;
		Scanner input = new Scanner(System.in);
		System.out.print("Input length, width, and height separated by spaces ");
		length = input.nextDouble();
		width = input.nextDouble();
		height = input.nextDouble();
		double price = calcWallAreaAndPrice(length, width, height);
		System.out.println("The cost to paint this room is $"+ price);

	}
		public static double calcWallAreaAndPrice(double length, double width, double height) { 
			double wallArea = 2*(length * height + width * height);
			double price = calcGallonsAndPrice(wallArea);
			return price;
		}
		public static double calcGallonsAndPrice(double wallArea) {
			double gallons = wallArea/350;
			double price = Math.ceil(gallons)* 32;
			
			return price;
			
		}

	
}
